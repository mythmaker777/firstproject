# SG Tuition Match Bot 🇸🇬

A Telegram bot for matching tuition tutors with parents/students in Singapore.

---

## Project Structure

```
tuition-bot/
├── bot.py           # All Telegram handlers and conversation flows
├── database.py      # SQLite database wrapper
├── requirements.txt # Python dependencies (only 2!)
├── .env.example     # Template for environment variables
├── Dockerfile       # For containerised deployment
└── README.md        # This file
```

---

## Quick Start (Local Development)

### Step 1 — Create your Telegram Bot

1. Open Telegram and search for **@BotFather**
2. Send `/newbot`
3. Give it a name: e.g. `SG Tuition Match`
4. Give it a username: e.g. `sg_tuition_match_bot` (must end in `bot`)
5. BotFather will give you a **token** that looks like: `7234567890:AAExx...`
6. Copy that token — you'll need it in Step 3

### Step 2 — Set up your environment

Make sure you have Python 3.11+ installed:
```bash
python --version
```

Clone the project and install dependencies:
```bash
cd tuition-bot
pip install -r requirements.txt
```

### Step 3 — Configure environment variables

```bash
cp .env.example .env
```

Edit `.env` and paste your bot token:
```
TELEGRAM_BOT_TOKEN=7234567890:AAExx...
```

### Step 4 — Run the bot

```bash
python bot.py
```

You should see: `Bot starting in polling mode...`

Open Telegram, find your bot by username, and send `/start`. 🎉

---

## Deployment Guide

### Option A: Railway (Recommended for MVP) 🚂

**Why Railway?**
- Easiest setup — connects to your GitHub repo and auto-deploys
- Free tier: $5 of credit/month (enough for a small bot)
- Persistent volume for your SQLite database
- Automatic HTTPS, logs, and restart on crash

**Steps:**
1. Push your code to a GitHub repository
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Select your repo
4. Add environment variable: `TELEGRAM_BOT_TOKEN` = your token
5. Add a **Volume** (under Storage) mounted at `/data` — this keeps your database alive across deploys
6. In the Dockerfile, the DB path is already set to `/data/tuition.db`
7. Deploy! Railway will build your Docker container automatically.

**Cost:** ~$0–$5/month on the free tier for a bot with <500 users.

---

### Option B: Render

Very similar to Railway. Free tier available.

1. Create account at [render.com](https://render.com)
2. New → Web Service → Connect GitHub repo
3. Set environment: `TELEGRAM_BOT_TOKEN`
4. Build command: `pip install -r requirements.txt`
5. Start command: `python bot.py`
6. Add a **Disk** (under Advanced) mounted at `/data`

**Note:** Render's free tier spins down after 15 minutes of inactivity. Since a Telegram bot
polls continuously, it won't spin down — but if you switch to webhooks, use a paid plan.

**Cost:** Free tier works. Paid starter plan: ~$7/month USD.

---

### Option C: DigitalOcean Droplet (Most Control)

Best if you want to run multiple services (e.g., bot + an admin web dashboard later).

**Steps:**
```bash
# 1. Create a $6/month Droplet (Ubuntu 24.04, 1GB RAM)
# 2. SSH into it
ssh root@your_droplet_ip

# 3. Install Python and git
apt update && apt install -y python3 python3-pip python3-venv git

# 4. Clone your repo
git clone https://github.com/your/repo.git /opt/tuition-bot
cd /opt/tuition-bot

# 5. Set up virtual environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# 6. Set environment variable
echo "TELEGRAM_BOT_TOKEN=your_token_here" > .env

# 7. Create a systemd service so the bot restarts automatically
cat > /etc/systemd/system/tuition-bot.service << EOF
[Unit]
Description=Tuition Match Telegram Bot
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/tuition-bot
EnvironmentFile=/opt/tuition-bot/.env
ExecStart=/opt/tuition-bot/venv/bin/python bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# 8. Start the service
systemctl daemon-reload
systemctl enable tuition-bot
systemctl start tuition-bot

# 9. Check logs
journalctl -u tuition-bot -f
```

**Cost:** $6/month USD (~$8 SGD) for a 1GB RAM Droplet.

---

## Cost Comparison

| Option         | Setup Effort | Cost/month | Best For                    |
|----------------|-------------|------------|------------------------------|
| Railway        | Very easy   | $0–$5      | MVP, first 500 users         |
| Render         | Very easy   | $0–$7      | MVP, similar to Railway      |
| DigitalOcean   | Moderate    | $6–$12     | 1,000+ users, more control   |
| AWS EC2 t3.micro | Hard      | ~$10       | If you already use AWS       |

**Bottom line:** Start with Railway. When you hit $5/month on free credits, upgrade to their $5/month Hobby plan. Move to DigitalOcean when you need more control or are running other services.

---

## Polling vs Webhook

The bot currently uses **polling** (bot asks Telegram for updates every second).

**Polling** — fine for development and small bots. No server setup required.

**Webhook** — Telegram pushes updates to your server the instant they arrive. More efficient, lower latency, better for production.

To switch to webhook mode, replace `app.run_polling(...)` in `bot.py` with:
```python
app.run_webhook(
    listen="0.0.0.0",
    port=8443,
    url_path=token,
    webhook_url=f"https://your-domain.com/{token}",
)
```

You'll also need an HTTPS URL (Railway and Render provide this automatically).

---

## When to Upgrade from SQLite to PostgreSQL

SQLite is great for MVP. Switch to PostgreSQL when:
- You have 1,000+ active users with frequent concurrent writes
- You want to run analytics queries without slowing down the bot
- You need full-text search on tutor profiles

Railway and Render both offer one-click PostgreSQL add-ons (~$5–$7/month).
Migration: change `_get_conn()` in `database.py` to use `psycopg2` and a `DATABASE_URL` env var.

---

## Monetisation Implementation Notes

The code includes a `payments` table in the database, ready for you to build on.

**Recommended first monetisation step:**
Charge tutors a fee via PayNow/PayLah when they successfully connect with a parent.
You can automate this by sending a PayNow QR code in the bot after a match is made.

For Stripe integration (credit card payments), use the `stripe` Python library and
add a payment link generation step in `express_interest()` before sharing contact details.

---

## Commands Reference

| Command      | Who uses it | Description                        |
|--------------|-------------|-------------------------------------|
| /start       | Everyone    | Main menu                           |
| /register    | Tutors      | Register or update tutor profile    |
| /postjob     | Parents     | Post a new tuition job              |
| /browse      | Tutors      | Browse open job listings            |
| /myjobs      | Everyone    | View your own postings              |
| /cancel      | Everyone    | Cancel current operation            |
